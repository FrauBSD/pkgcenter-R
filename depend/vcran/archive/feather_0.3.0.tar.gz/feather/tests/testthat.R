library(testthat)
library(feather)

test_check("feather")
